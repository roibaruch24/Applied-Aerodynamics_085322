function colors = generateColorVector(numColors)
    colors = lines(numColors);
end